package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaProyectoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaProyectoApplication.class, args);
	}

}
