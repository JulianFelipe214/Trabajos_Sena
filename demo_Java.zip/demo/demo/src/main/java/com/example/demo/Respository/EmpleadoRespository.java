package com.example.demo.Respository;

import com.example.demo.Entity.Empleado;
import  org.springframework.data.repository.CrudRepository;

public interface EmpleadoRespository extends CrudRepository<Empleado, Long> {
}
