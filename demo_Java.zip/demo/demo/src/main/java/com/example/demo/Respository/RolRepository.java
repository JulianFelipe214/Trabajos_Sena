package com.example.demo.Respository;

public interface RolRepository {
}
