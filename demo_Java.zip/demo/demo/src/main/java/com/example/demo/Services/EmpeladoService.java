package com.example.geffer.springproject.Services;
import com.example.demo.Entity.Empleado;
import com.example.demo..Repository.EmpleadoRepo;
import com.example.demo.Respository.EmpleadoRespository;
import com.example.demo.ServicesInterfaces.Empleadolmpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EmpleadoService implements Empleadolmpl {

    @Autowired
    private EmpleadoRespository empleadoRepository;

    @Override
    public List<Empleado> obtenerTodosLosEmpleados() {
        List<Empleado> empleados = new ArrayList<>();
        empleadoRepository.findAll().forEach(empleados::add);
        return empleados;
    }

    @Override
    public Empleado obtenerEmpleadoPorId(Long id) {
        Optional<Empleado> empleado = empleadoRepository.findById(id);
        return empleado.orElse(null);
    }

    @Override
    public Empleado guardarEmpleado(Empleado empleado) {
        return empleadoRepository.save(empleado);
    }

    @Override
    public void eliminarEmpleado(Long id) {
        empleadoRepository.deleteById(id);
    }
}