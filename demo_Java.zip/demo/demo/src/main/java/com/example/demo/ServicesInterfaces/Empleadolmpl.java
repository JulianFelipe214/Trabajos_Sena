package com.example.demo.ServicesInterfaces;

package com.example.demo.ServicesInterfaces;
import com.example.demo.Entity.Empleado;
import java.util.List;

public interface Empleadolmpl {
    List<Empleado> obtenerTodosLosEmpleado();
    Empleado btenerTodosLosEmpleadoPorId(Long id);
    Empleado guardarEmpelado(Empleado empleado);
    void eliminarEmpleado(Long id);

}
